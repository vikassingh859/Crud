﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CRUDProject.Models;

namespace CRUDProject.Controllers
{
    public class CustomersController : Controller
    {
        private ABCEntities db = new ABCEntities();
        
        public ActionResult Index()
        {
            ABCEntities entities = new ABCEntities();
            List<Customer> customers = entities.Customers.ToList();

            //Add a Dummy Row.
            customers.Insert(0, new Customer());
            return View(customers);
        }
        [HttpPost]
        public JsonResult InsertCustomer(Customer customer)
        {
            using (ABCEntities entities = new ABCEntities())
            {
                entities.Customers.Add(customer);
                entities.SaveChanges();
            }

            return Json(customer);
        }
        [HttpPost]
        public ActionResult UpdateCustomer(Customer customer)
        {
            using (ABCEntities entities = new ABCEntities())
            {
                Customer updatedCustomer = (from c in entities.Customers
                                            where c.CustomerId == customer.CustomerId
                                            select c).FirstOrDefault();
                updatedCustomer.Name = customer.Name;
                updatedCustomer.Country = customer.Country;
                entities.SaveChanges();
            }

            return new EmptyResult();
        }

        [HttpPost]
        public ActionResult DeleteCustomer(int customerId)
        {
            using (ABCEntities entities = new ABCEntities())
            {
                Customer customer = (from c in entities.Customers
                                     where c.CustomerId == customerId
                                     select c).FirstOrDefault();
                entities.Customers.Remove(customer);
                entities.SaveChanges();
            }

            return new EmptyResult();
        }

    }
}
